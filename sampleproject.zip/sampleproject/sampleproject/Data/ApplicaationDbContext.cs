﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using sampleproject.Models;

namespace sampleproject.Data
{
    public class ApplicaationDbContext:DbContext
    {
        public ApplicaationDbContext(DbContextOptions<ApplicaationDbContext>options):base(options) 
        {
           
        }

        public DbSet<Accounts> Accounts { get; set; }
        public DbSet<Profile> Profiles { get; set; }
    }
}
