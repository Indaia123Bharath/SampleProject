﻿using Microsoft.AspNetCore.Mvc;
using sampleproject.Data;
using sampleproject.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace sampleproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase

    {
        private readonly ApplicaationDbContext _applicaationDbContext;

        public AccountsController(ApplicaationDbContext applicaationDbContext)
        {
            _applicaationDbContext = applicaationDbContext;
        }


        // GET: api/<AccountsController>
        [HttpGet]
        public IActionResult Get()
        {

            
            var months = DateTime.Now.AddMonths(-6);

            var result = from ecm in _applicaationDbContext.Accounts
                         join pcm in _applicaationDbContext.Profiles
                         on ecm.Account_Id equals pcm.profileId
                         select new
                         {
                            AcountId = ecm.Account_Id,
                            Email = ecm.Email,
                            RegestredDate =pcm.Regesteredout

                         };
           
            return Ok(result);
        }

        // GET api/<AccountsController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<AccountsController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<AccountsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AccountsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
