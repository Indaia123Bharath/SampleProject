﻿using System.ComponentModel.DataAnnotations;

namespace sampleproject.Models
{
    public class Accounts
    {
        [Key]
        public int Account_Id { get; set; }
        public string Email {  get; set; }
        public DateTime RegestredDate { get; set; }

        public ICollection<Profile> Profiles { get; set; }
    }
}
