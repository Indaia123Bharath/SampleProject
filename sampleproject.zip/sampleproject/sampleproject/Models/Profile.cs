﻿using System.ComponentModel.DataAnnotations;

namespace sampleproject.Models
{
    public class Profile
    {
        [Key]
        public int profileId {  get; set; }
        public DateTime Regesteredout { get; set; }
        public int AccountId { get; set; }
        public Accounts Accounts { get; set; }
    }
}
